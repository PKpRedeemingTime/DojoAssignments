FactoryGirl.define do
  factory :message do
    message "MyTextRightHere"
    user nil
  end
end
