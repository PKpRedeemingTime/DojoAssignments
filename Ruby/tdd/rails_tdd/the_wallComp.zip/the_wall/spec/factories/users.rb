FactoryGirl.define do
  factory :user do
    username "Patrick"
  end
end
