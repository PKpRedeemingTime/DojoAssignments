require 'rails_helper'

RSpec.describe UsersController, type: :controller do

end
